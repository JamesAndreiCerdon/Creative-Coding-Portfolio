function setup() {
  createCanvas(400, 600);
}

function draw() {
  background(255);

 
  fill(255, 204, 0); 
  noStroke();
  ellipse(width / 2, height / 2, 200, 200); 


  fill(210, 105, 30); 
  triangle(width / 2 - 60, height / 2 + 100, width / 2 + 60, height / 2 + 100, width / 2, height); 
}
