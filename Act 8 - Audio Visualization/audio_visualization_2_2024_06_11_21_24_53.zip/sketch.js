let song;
let fft;

function preload() {
  song = loadSound('Youre Everything.mp3');
}

function setup() {
  createCanvas(800, 750);
  
  // Create an FFT object
  fft = new p5.FFT();
  
  // Play the audio file
  song.play();
}

function draw() {
  background(30);
  
  // Analyze the audio spectrum
  let spectrum = fft.analyze();
  
  // Draw spectrum bars
  for (let i = 0; i < spectrum.length; i++) {
    let x = map(i, 0, spectrum.length, 0, width);
    let h = -height + map(spectrum[i], 0, 255, height, 0);
    let c = map(i, 0, spectrum.length, 0, 255);
    let bright = map(spectrum[i], 0, 255, 50, 255);
    let sw = map(spectrum[i], 0, 255, 2, 10);
    
    // Set bar color
    stroke(c, bright, 255);
    strokeWeight(sw);
    
    // Draw the bar
    line(x, height, x, h + height);
  }
}
