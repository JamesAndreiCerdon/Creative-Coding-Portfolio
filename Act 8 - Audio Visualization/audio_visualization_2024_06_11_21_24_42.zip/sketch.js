let song;
let fft;

function preload() {
  // Load your audio file
  song = loadSound('The Platters - Only You.mp3');
}

function setup() {
  createCanvas(1000, 400);

  // Create an FFT object to analyze the audio
  fft = new p5.FFT();

  // Play the loaded audio file
  song.play();
}

function draw() {
  background(0);

  // Analyze the audio waveform
  let waveform = fft.waveform();

  // Draw the waveform
  noFill();
  stroke(255);
  beginShape();
  for (let i = 0; i < waveform.length; i++) {
    let x = map(i, 0, waveform.length, 0, width);
    let y = map(waveform[i], -1, 1, 0, height);
    vertex(x, y);
  }
  endShape();
}

let playButton = createButton('Play');
  playButton.position(width / 2 - 25, height - 50);
  playButton.mousePressed(startPlaying);