let trail = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);
}

function draw() {
  background(255, 10); 

  
  let position = createVector(mouseX, mouseY);
  trail.push(position);

  
  if (trail.length > 50) {
    trail.splice(0, 1);
  }

 
  noFill();
  stroke(0);
  beginShape();
  for (let i = 0; i < trail.length; i++) {
    let pos = trail[i];
    vertex(pos.x, pos.y);
  }
  endShape();
}
