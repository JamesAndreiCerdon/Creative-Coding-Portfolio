let trail = [];

function setup() {
  createCanvas(600, 400);
}


function draw() {
  background(220);

 
  trail.push(createVector(mouseX, mouseY));

  if (trail.length > 50) {
    trail.splice(0, 1);
  }

  
  noFill();
  stroke(0);
  for (let i = 0; i < trail.length; i++) {
    let alpha = map(i, 0, trail.length - 1, 0, 255);
    stroke(0, alpha);
    let pos = trail[i];
    ellipse(pos.x, pos.y, 10, 10);
  }
}
