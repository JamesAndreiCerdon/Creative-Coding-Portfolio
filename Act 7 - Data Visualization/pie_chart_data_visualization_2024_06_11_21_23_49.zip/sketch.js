let data = [100, 200, 150, 250, 300, 175];
let colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A8', '#FFDB33', '#33FFF5'];
let labels = ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6'];

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(220);

  let total = data.reduce((a, b) => a + b, 0);
  let lastAngle = 0;
  let cx = width / 2;
  let cy = height / 2;
  let radius = 150;

  for (let i = 0; i < data.length; i++) {
    let angle = (data[i] / total) * TWO_PI;

    // Draw pie slice
    fill(colors[i]);
    arc(cx, cy, radius * 2, radius * 2, lastAngle, lastAngle + angle, PIE);

    // Calculate the position for the text inside the slice
    let midAngle = lastAngle + angle / 2;
    let x = cx + cos(midAngle) * radius / 2;
    let y = cy + sin(midAngle) * radius / 2;

    // Draw text
    fill(0);
    textSize(12);
    text(`${labels[i]}: $${data[i]}`, x, y);

    lastAngle += angle;
  }
}
