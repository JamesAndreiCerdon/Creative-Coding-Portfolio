let data = [100, 200, 150, 250, 300, 175];
let colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A8', '#FFDB33', '#33FFF5'];

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, BOTTOM); // Align text center and bottom for labels above the bars
}

function draw() {
  background(220);
  
  let barWidth = width / data.length;

  for (let i = 0; i < data.length; i++) {
    fill(colors[i]);
    let barHeight = data[i];
    rect(i * barWidth, height - barHeight, barWidth - 10, barHeight);

    fill(0); // Set fill color to black for the text
    text(data[i], i * barWidth + (barWidth - 10) / 2, height - barHeight - 5); // Display the data value above the bar
  }
}
