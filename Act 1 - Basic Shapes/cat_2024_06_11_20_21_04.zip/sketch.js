function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // Body
  fill(255, 204, 0);
  ellipse(200, 300, 150, 100);

  // Head
  fill(255, 204, 0);
  ellipse(200, 200, 100, 100);

  // Eyes
  fill(255);
  ellipse(180, 180, 30, 30);
  ellipse(220, 180, 30, 30);

  // Pupils
  fill(0);
  ellipse(180, 180, 10, 10);
  ellipse(220, 180, 10, 10);

  // Nose
  fill(255, 102, 102);
  triangle(200, 200, 195, 215, 205, 215);

  // Whiskers
  stroke(0);
  line(170, 200, 150, 190);
  line(170, 200, 150, 210);
  line(230, 200, 250, 190);
  line(230, 200, 250, 210);

  // Ears
  fill(255, 204, 0);
  triangle(150, 130, 180, 150, 150, 170);
  triangle(250, 130, 220, 150, 250, 170);

  // Mouth
  noFill();
  arc(200, 220, 40, 20, 0, PI);
}
