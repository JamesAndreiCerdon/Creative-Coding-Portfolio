function setup() {
  createCanvas(800, 600);
  background(255);

  // Body
  fill(255);
  ellipse(400, 300, 300, 400);

  // Ears
  fill(0);
  ellipse(310, 150, 100, 100);
  ellipse(490, 150, 100, 100);

  // Face
  fill(255);
  ellipse(400, 250, 250, 300);

  // Eyes
  fill(0);
  ellipse(350, 220, 70, 90);
  ellipse(450, 220, 70, 90);

  fill(255);
  ellipse(350, 220, 30, 50);
  ellipse(450, 220, 30, 50);

  // Nose
  fill(0);
  ellipse(400, 300, 30, 20);

  // Mouth
  noFill();
  stroke(0);
  strokeWeight(5);
  arc(400, 320, 50, 30, 0, PI);

  // Arms
  fill(0);
  ellipse(270, 400, 100, 150);
  ellipse(530, 400, 100, 150);

  // Legs
  ellipse(350, 500, 100, 150);
  ellipse(450, 500, 100, 150);
}

function draw() {
  // The static drawing code is within the setup function, 
  // so draw is not used in this case.
}
