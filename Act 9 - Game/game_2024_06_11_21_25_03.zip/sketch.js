let paddle;
let ball;
let bricks = [];
let brickRows = 4;
let brickCols = 10;
let brickWidth = 60;
let brickHeight = 20;
let gameOver = false;
let gameWon = false;
let restartButton;

function setup() {
  createCanvas(600, 400);
  paddle = new Paddle();
  ball = new Ball();
  createBricks();
  restartButton = createButton('Restart');
  restartButton.position(width / 2 - 40, height / 2 + 50);
  restartButton.mousePressed(restartGame);
  restartButton.hide(); // Initially hide the button
}

function draw() {
  background(0);

  if (!gameOver && !gameWon) {
    // Update and display paddle
    paddle.update();
    paddle.display();

    // Update and display ball
    ball.update();
    ball.display();

    // Check for collisions with paddle
    if (ball.hitsPaddle(paddle)) {
      ball.bouncePaddle(paddle);
    }

    // Update and display bricks
    for (let brick of bricks) {
      brick.display();
      if (ball.hitsBrick(brick)) {
        ball.bounceBrick(brick);
        bricks.splice(bricks.indexOf(brick), 1);
        break;
      }
    }

    // Check for game over
    if (ball.y > height) {
      gameOver = true;
      restartButton.show(); // Show the button when the game is over
    }

    // Check for game win
    if (bricks.length === 0) {
      gameWon = true;
      restartButton.show(); // Show the button when the game is won
    }
  } else {
    textSize(32);
    textAlign(CENTER, CENTER);
    fill(255);
    if (gameOver) {
      text("Game Over", width / 2, height / 2);
    } else if (gameWon) {
      text("You Win!", width / 2, height / 2);
    }
  }
}

function createBricks() {
  bricks = [];
  for (let i = 0; i < brickRows; i++) {
    for (let j = 0; j < brickCols; j++) {
      let x = j * (brickWidth + 10) + 3;
      let y = i * (brickHeight + 10) + 30;
      bricks.push(new Brick(x, y));
    }
  }
}

function restartGame() {
  gameOver = false;
  gameWon = false;
  ball = new Ball();
  paddle = new Paddle();
  createBricks();
  restartButton.hide();
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    paddle.moveLeft();
  } else if (keyCode === RIGHT_ARROW) {
    paddle.moveRight();
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    paddle.stop();
  }
}

class Paddle {
  constructor() {
    this.width = 100;
    this.height = 20;
    this.x = width / 2 - this.width / 2;
    this.y = height - 40;
    this.speed = 8;
    this.isMovingLeft = false;
    this.isMovingRight = false;
  }

  update() {
    if (this.isMovingLeft) {
      this.x = constrain(this.x - this.speed, 0, width - this.width);
    } else if (this.isMovingRight) {
      this.x = constrain(this.x + this.speed, 0, width - this.width);
    }
  }

  display() {
    fill(255);
    rect(this.x, this.y, this.width, this.height);
  }

  moveLeft() {
    this.isMovingLeft = true;
  }

  moveRight() {
    this.isMovingRight = true;
  }

  stop() {
    this.isMovingLeft = false;
    this.isMovingRight = false;
  }
}

class Ball {
  constructor() {
    this.radius = 10;
    this.x = width / 2;
    this.y = height / 2;
    this.vx = random(-5, 5);
    this.vy = -5;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    // Bounce off walls
    if (this.x - this.radius < 0 || this.x + this.radius > width) {
      this.vx *= -1;
    }
    if (this.y - this.radius < 0) {
      this.vy *= -1;
    }
  }

  display() {
    fill(255);
    ellipse(this.x, this.y, this.radius * 2);
  }

  hitsPaddle(paddle) {
    return (this.x > paddle.x && this.x < paddle.x + paddle.width && this.y + this.radius >= paddle.y);
  }

  bouncePaddle(paddle) {
    let dx = this.x - (paddle.x + paddle.width / 2);
    this.vy *= -1;
    this.vx = map(dx, -paddle.width / 2, paddle.width / 2, -5, 5);
  }

  hitsBrick(brick) {
    return (this.x > brick.x && this.x < brick.x + brick.width &&
            this.y - this.radius < brick.y + brick.height &&
            this.y + this.radius > brick.y);
  }

  bounceBrick(brick) {
    this.vy *= -1;
  }
}

class Brick {
  constructor(x, y) {
    this.width = brickWidth;
    this.height = brickHeight;
    this.x = x;
    this.y = y;
  }

  display() {
    fill(255);
    rect(this.x, this.y, this.width, this.height);
  }
}
