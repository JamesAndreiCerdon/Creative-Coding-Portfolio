var img;
function preload(){
  img = loadImage('dog and chick into one.jpg');
}

function setup() {
  createCanvas(225, 225);
}

function draw() {
  background(220);
  image(img,0,0)
  filter(POSTERIZE)
}