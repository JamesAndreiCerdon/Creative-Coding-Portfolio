let img;
let pixelDensity = 8; // Adjust the pixel density for more or less detail

function preload() {
  // Load an image
  img = loadImage('bear.jpg');
}

function setup() {
  createCanvas(800, 600);
  img.resize(width, height);
  noStroke();
}

function draw() {
  background(255);
  
  // Iterate through each pixel of the image
  for (let y = 0; y < img.height; y += pixelDensity) {
    for (let x = 0; x < img.width; x += pixelDensity) {
      // Get the color of the pixel
      let c = img.get(x, y);
      // Calculate the brightness of the pixel
      let brightness = (red(c) + green(c) + blue(c)) / 3;
      // Calculate the radius of the ellipse based on the brightness
      let radius = map(brightness, 0, 255, 0, pixelDensity * 4);
      // Set the fill color
      fill(c);
      // Draw an ellipse at the pixel position
      ellipse(x, y, radius, radius);
    }
  }
}
