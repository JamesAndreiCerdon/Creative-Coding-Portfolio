function setup() {
  createCanvas(400, 400);
  background(255);
  let tileSize = 40; // Size of each tile
  let rows = height / tileSize; // Number of rows
  let cols = width / tileSize; // Number of columns

  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      if ((i + j) % 2 === 0) { // Check if row + column is even
        fill(0); // Black
      } else {
        fill(255); // White
      }
      rect(j * tileSize, i * tileSize, tileSize, tileSize); // Draw rectangle
    }
  }
}
